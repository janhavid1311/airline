package com.airline_reservation.dao;

import com.airline_reservation.model.Admin;
import com.airline_reservation.model.User;

public interface UserDaoIntf {
	boolean register(User user);
	 public User checkUserLogin(User user);

}
