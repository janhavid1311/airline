package com.airline_reservation.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.airline_reservation.model.Admin;
import com.airline_reservation.model.User;

@Repository("userDao")
public class UserDaoImpl implements UserDaoIntf{

	@PersistenceContext
	EntityManager em;
	public boolean register(User user) {
		boolean flag=false;
	    try {
	    	System.out.println(user);
		/*em.getTransaction().begin( ); */
		em.persist(user);
		//em.getTransaction().commit();
		//em.close();
		System.out.println("end");
		flag=true;
	    }
	    catch(Exception e) { System.out.println("Error:"+e);  }
	    return flag;
	}

	public User checkUserLogin(User user) {
		
			User ad =null;
			try{
				ad=(User)em.createQuery("SELECT u FROM User u WHERE u.email_id=:email_id and u.password=:password")
			         .setParameter("email_id", user.getEmail_id())
			         .setParameter("password",user.getPassword())
			         .getSingleResult();
			}
			catch(Exception e) {
				System.out.println(e); 
				}
			//em.close();
			System.out.println(ad);
			return ad;
	}

	

}
