package com.airline_reservation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.airline_reservation.dao.UserDaoImpl;
import com.airline_reservation.model.Admin;
import com.airline_reservation.model.User;


@Service("userService")
public class UserServiceImpl implements UserServiceIntf{
	 @Autowired
	  public UserDaoImpl userDao;

	 @Transactional
	public boolean register(User user) {
		return userDao.register(user);
	}

	 @Transactional
	public User checkUserLogin(User user) {
		return userDao.checkUserLogin(user);
	}

}
