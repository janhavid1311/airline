package com.airline_reservation.service;

import com.airline_reservation.model.Admin;
import com.airline_reservation.model.User;

public interface UserServiceIntf {	
	public boolean register(User user);
	public User checkUserLogin(User user);
}
